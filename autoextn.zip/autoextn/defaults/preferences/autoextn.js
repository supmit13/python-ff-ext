// See http://kb.mozillazine.org/Localize_extension_descriptions
pref("extensions.smitra@localhost.description", "chrome://autoextn/locale/autoextn.properties");
